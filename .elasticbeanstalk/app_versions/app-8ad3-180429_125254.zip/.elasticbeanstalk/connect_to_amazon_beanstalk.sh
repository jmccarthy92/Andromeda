ssh -i "C:\Users\globe\.ssh\Andromeda.pem" ec2-user@ec2-18-188-253-230.us-east-2.compute.amazonaws.com
