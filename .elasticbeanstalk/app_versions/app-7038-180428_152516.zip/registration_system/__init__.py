default_app_config = 'Andromeda.registration_system.apps.RegistrationSystemConfig'
